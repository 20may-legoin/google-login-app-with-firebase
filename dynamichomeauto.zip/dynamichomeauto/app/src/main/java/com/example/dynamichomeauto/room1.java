package com.example.dynamichomeauto;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class room1 extends AppCompatActivity {

    Switch fan1S, fan2S, bulb1S, bulb2S, bulb3S, bulb4S, bulb5S, bulb6S;

    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fan1S = findViewById(R.id.switchFanOne);
        fan2S = findViewById(R.id.switchFanTwo);

        bulb1S = findViewById(R.id.switchBulbOne);
        bulb2S = findViewById(R.id.switchBulbTwo);
        bulb3S = findViewById(R.id.switchBulbThree);
        bulb4S = findViewById(R.id.switchBulbFour);
        bulb5S = findViewById(R.id.switchBulbFive);
        bulb6S = findViewById(R.id.switchBulbSix);

        database = FirebaseDatabase.getInstance();
        reference = database.getReference();

        bulb1S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb1S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb1 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb1").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb1 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb1").setValue("0");
                }
            }
        });

        bulb2S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb2S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb2 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb2").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb2 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb2").setValue("0");
                }
            }
        });

        bulb3S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb3S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb3 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb3").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb3 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb3").setValue("0");
                }
            }
        });

        bulb4S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb4S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb4 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb4").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb4 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb4").setValue("0");
                }
            }
        });

        bulb5S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb5S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb5 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb5").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb5 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb5").setValue("0");
                }
            }
        });

        bulb6S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bulb6S.isChecked()) {
                    Toast.makeText(room1.this, "Bulb6 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb6").setValue("1");
                }else{
                    Toast.makeText(room1.this, "Bulb6 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("bulb6").setValue("0");
                }
            }
        });

        fan1S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fan1S.isChecked()) {
                    Toast.makeText(room1.this, "fan1 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("fan1").setValue("1");
                }else{
                    Toast.makeText(room1.this, "fan1 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("fan1").setValue("0");
                }
            }
        });

        fan2S.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fan2S.isChecked()) {
                    Toast.makeText(room1.this, "fan2 is on", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("fan2").setValue("1");
                }else{
                    Toast.makeText(room1.this, "fan2 is off", Toast.LENGTH_SHORT).show();
                    reference.child("vismays_room").child("fan2").setValue("0");
                }
            }
        });

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String fan1, fan2, bulb1, bulb2, bulb3, bulb4, bulb5, bulb6;

                fan1 = dataSnapshot.child("vismays_room").child("fan1").getValue(String.class);
                fan2 = dataSnapshot.child("vismays_room").child("fan2").getValue(String.class);
                bulb1 = dataSnapshot.child("vismays_room").child("bulb1").getValue(String.class);
                bulb2 = dataSnapshot.child("vismays_room").child("bulb2").getValue(String.class);
                bulb3 = dataSnapshot.child("vismays_room").child("bulb3").getValue(String.class);
                bulb4 = dataSnapshot.child("vismays_room").child("bulb4").getValue(String.class);
                bulb5 = dataSnapshot.child("vismays_room").child("bulb5").getValue(String.class);
                bulb6 = dataSnapshot.child("vismays_room").child("bulb6").getValue(String.class);

                if(fan1.equals("1")){
                    fan1S.setChecked(true);
                }else if(fan1.equals("0")){
                    fan1S.setChecked(false);
                }

                if(fan2.equals("1")){
                    fan2S.setChecked(true);
                }else if(fan2.equals("0")){
                    fan2S.setChecked(false);
                }

                if(bulb1.equals("1")){
                    bulb1S.setChecked(true);
                }else if(bulb1.equals("0")){
                    bulb1S.setChecked(false);
                }

                if(bulb2.equals("1")){
                    bulb2S.setChecked(true);
                }else if(bulb2.equals("0")){
                    bulb2S.setChecked(false);
                }

                if(bulb3.equals("1")){
                    bulb3S.setChecked(true);
                }else if(bulb3.equals("0")){
                    bulb3S.setChecked(false);
                }

                if(bulb4.equals("1")){
                    bulb4S.setChecked(true);
                }else if(bulb4.equals("0")){
                    bulb4S.setChecked(false);
                }

                if(bulb5.equals("1")){
                    bulb5S.setChecked(true);
                }else if(bulb5.equals("0")){
                    bulb5S.setChecked(false);
                }

                if(bulb6.equals("1")){
                    bulb6S.setChecked(true);
                }else if(bulb6.equals("0")){
                    bulb6S.setChecked(false);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
